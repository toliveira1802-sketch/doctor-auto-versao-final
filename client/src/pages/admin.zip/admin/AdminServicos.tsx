import { AdminLayout } from "@/components/layout/AdminLayout";

export default function AdminServicos() {
  return (
    <AdminLayout>
      <div className="p-6">
        <h1 className="text-2xl font-bold">Serviços</h1>
        <p className="text-muted-foreground mt-2">Em breve...</p>
      </div>
    </AdminLayout>
  );
}
